#include "ku_common.h"


void tasklet_func(unsigned long recv_data) {
	struct ku_list *temp_data;
	temp_data = (struct ku_list *) recv_data;
	printk("LED ON\n");
	// turn on the led
	gpio_set_value(LED1, 1);
	
		
}


static irqreturn_t tasklet_isr(int irq, void* data) {
	tasklet_schedule(&my_tasklet);
	return IRQ_HANDLED;
}


