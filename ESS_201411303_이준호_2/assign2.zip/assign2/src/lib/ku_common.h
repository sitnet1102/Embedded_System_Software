// library
#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/gpio.h>
#include <linux/timer.h>
#include <linux/rculist.h>
#include <linux/slab.h>
#include <linux/interrupt.h>
#include <linux/uaccess.>
#include <asm/delay.h>
#include <linux/timer.h>
#include <linux/workqueue.h>
#include <sys/time.h>

MODULE_LICENSE("GPL");

// definition
#define LED1 			4
#define SPEAKER 		12
#define ULTRA_TRIG 		17
#define ULTRA_ECHO		18

#define DEV_NAME "ku_dev"

#define IOCTL_START_NUM 	0x80
#define IOCTL_NUM1 		IOCTL_START_NUM+1
#define IOCTL_NUM2 		IOCTL_START_NUM+2

#define KU_IOCTL_NUM 		'z'
#define IOCTL_READ		_IOWR(KU_IOCTL_NUM, IOCTL_NUM1, unsigned long *)
#define IOCTL_WRITE 		_IOWR(KU_IOCTL_NUM, IOCTL_NUM2, unsigned long *)

#define FAIL 			0xFF	//1111 1111
#define SENSED			0xF0	//1111 0000
#define NOTHING			0x00	//0000 0000

// 	structure
// data list
struct ku_list {
	struct list_head *list;
	struct tm timestamp;
	long value;
	int mode;
};

// timer 
struct my_timer_info {
	struct time_list timer;
	long delay_jiffies;
};

//	static value
// device value
static dev_t dev_num;
static struct cdev *cd_cdev;

// lock value
spinlock_t my_lock;

// irq value
static int irq_num;
static int irq_num2;
static int echo_valid_flag = 3;
static int act_flag = 3;

// ultrasonic value
static ktime_t echo_start;
static ktime_t echo_stop;

// list head
static struct ku_list __rcu mylist;

// tasklet
static struct tasklet_struct my_tasklet;

// workqueue
static struct workqueue_struct *my_wq;

// timer 
static struct my_timer_info my_timer;




